/******************************************************/
/* Ejemplo 1: Encendido de LED */
/* main.c */
/* Fecha: Mayo 2, 2008 */
/* V1.0, Rev 0 por Diego Munera */
/* Asunto: */
/* Implementar un codigo en C */
/* que realice encendido y apagado */
/* periodico del led en PTD2 de la */
/* tarjeta de evaluacion DEMOJM */
/* */
/* NOTA: Las tildes en los comentarios */
/* son omitidas, para efectos de */
/* compatibilidad con otros editores */
/******************************************************/
/* Archivos de cabecera */

#include <hidef.h> // macro para habilitar interrupciones
#include "derivative.h" // declaracion de perifericos
/* Macros y definiciones */
#define Disable_COP() SOPT1 &= 0x3F //deshabilita el COP
#define Led1_On() PTDD_PTDD2 = 0; PTDDD_PTDDD2 = 1 //macro para encendido del LED PTD2
#define Led1_Off() PTDD_PTDD2 =1; PTDDD_PTDDD2 = 1 //macro para apagado del LED PTD2
/* Funcion Delay(): Retarda basado en una variable tipo entera*/
void Delay(void){
    unsigned int i;
    i= 30000; //inicializa contador i en 30000

    while(i > 0){              //llego a cero?
                i--;           //no --> decrementa
              }
}
/* main(): Funcion principal*/
void main(void) {
                  MCGC1=0x04; //Reloj en modo FEI y divisor por 1
                  MCGC2=0x00;
                  Disable_COP(); //deshabilita el COP
                  EnableInterrupts; //habilita interrupciones
                  
          for(;;) { //iteracion infinita
            Led1_On(); //enciende el Led1
            Delay(); //llama funcion de retardo: Delay
           
            Led1_Off(); //apaga el Led1
            Delay(); //llama funcion de retardo: Delay
    } /* es necesario asegurarse de nunca abandonar el main */
}