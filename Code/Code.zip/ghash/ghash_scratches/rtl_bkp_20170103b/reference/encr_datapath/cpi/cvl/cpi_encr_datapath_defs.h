#define CPI_ENCR_DATAPATH__I_RF_STATIC_MODE                                                         (dynamic_cast<sc_signal<sc_lv<8> >* >( rfport_table[0] ))
