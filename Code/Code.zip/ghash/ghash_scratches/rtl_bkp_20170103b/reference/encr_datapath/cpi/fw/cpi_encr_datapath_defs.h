#define CPI_ENCR_DATAPATH__I_RF_STATIC_MODE                                                         this->offset+0,7,0
