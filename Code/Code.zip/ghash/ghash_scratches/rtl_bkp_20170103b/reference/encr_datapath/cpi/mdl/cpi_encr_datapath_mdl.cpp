/**
* \class Cpi_Encr_Datapath
* \ingroup      
* \date </DATE>
* \author Script
* 
* \brief Derived class used for port connection only in CVL environment
*
* \copyright Copyright (C), ClariPhy Argentina. All rights reserved.
* 
*/    

#include "cpi_encr_datapath_mdl.h"


