/**
* \class Cpi_Encr_Datapath
* \ingroup      
* \date </DATE>
* \author Script
* 
* \brief encr_datapath configuration methods
*
* \copyright Copyright (C), ClariPhy Argentina. All rights reserved.
* 
*/    

#include "cpi_encr_datapath.h"

using namespace cpi;
    
void Cpi_Encr_Datapath::configure( UINT8 enable )
{
    //WR_PORT( MODULE__I_RF_STATIC_ENABLE, enable);
}

